public class CategoriaInvalidaException extends Throwable {
    public CategoriaInvalidaException() { }
    public CategoriaInvalidaException(String msg) {
        super(msg);
    }
}
