public class NumerInvalidoException extends Exception {
    public NumerInvalidoException() { }
    public NumerInvalidoException(String msg) {
        super(msg);
    }
}
