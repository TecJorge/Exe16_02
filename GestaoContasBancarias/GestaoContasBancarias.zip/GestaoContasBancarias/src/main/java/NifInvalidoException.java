public class NifInvalidoException extends Exception{
    public NifInvalidoException() { }
    public NifInvalidoException(String msg) {
        super(msg);
    }
}
