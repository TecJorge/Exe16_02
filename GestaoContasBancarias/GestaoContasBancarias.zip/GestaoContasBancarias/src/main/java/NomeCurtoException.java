public class NomeCurtoException extends Exception {
        public NomeCurtoException() { }
        public NomeCurtoException(String msg) {
            super(msg);
        }
    }

